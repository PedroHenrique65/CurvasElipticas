from ecdsa.ellipticcurve import CurveFp
from ecdsa.ellipticcurve import Point
from ecdsa.numbertheory import inverse_mod

# Usando a curva y² = x³ + 1
p = 17  # Primo p
a = 0   # Coeficiente a
b = 1   # Coeficiente b

# Cria a curva elíptica
curve = CurveFp(p, a, b)

# Função para somar dois pontos em uma curva elíptica
def add_points(P, Q):
    if P == Q:
        # Caso P seja igual a Q, dobramos o ponto P
        m = (3 * P.x() ** 2) * inverse_mod(2 * P.y(), p)
    else:
        # Caso P seja diferente de Q, calculamos a inclinação da reta
        m = (Q.y() - P.y()) * inverse_mod(Q.x() - P.x(), p)

    x_R = (m ** 2 - P.x() - Q.x()) % p
    y_R = (m * (P.x() - x_R) - P.y()) % p
    return Point(curve, x_R, y_R)

# Ponto base na curva
x_P = 2
y_P = 3

# Escolhendo um valor para escalar n
n = 5

# Realiza a adição de n vezes do ponto P a ele mesmo
result = Point(curve, x_P, y_P)
for _ in range(n - 1):
    result = add_points(result, Point(curve, x_P, y_P))

# Exibe as coordenadas do ponto resultante após a adição
print(f"Resultado da adição de {n} vezes o ponto P:")
print(f"X: {result.x()}")
print(f"Y: {result.y()}")
